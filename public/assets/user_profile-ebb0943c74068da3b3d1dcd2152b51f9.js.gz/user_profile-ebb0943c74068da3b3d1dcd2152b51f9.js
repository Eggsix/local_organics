$(document).ready(function() {
	$('.edit').hide();
	$('.edit_button').click(
		function() {
			$('.edit').toggle();
		})
});
